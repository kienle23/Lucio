﻿module.exports = (client, member) => {

  member.send(

    `Welcome to 'And I Boop'. Please read the rules, also message Rocket your comp rank. From your pal, Rocket😀`

  );

};
